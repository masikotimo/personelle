import java.rmi.Remote; 
import java.rmi.RemoteException;  
import java.util.*;
// Creating Remote interface for our application 
public interface Interface extends Remote {  
   
  // rmi helps us to create an architecture for client/server paradigm
	//it extends remote interface so that it can be accessed remotely
  public  double calculation(int x,int y, char op)throws RemoteException;
   
   
   
} 