import java.rmi.registry.Registry; 
import java.rmi.registry.LocateRegistry; 
import java.rmi.RemoteException; 
import java.rmi.server.UnicastRemoteObject;



public class Server extends Implementation { 
   public Server() {} 
   public static void main(String args[]) { 
      try { 
         // Instantiating the implementation class and its given the obj name of that object
         Implementation obj = new Implementation();
         
         
         // Exporting the object of implementation class  
         // exporting the remote object to the stub 
         
         // registry creates a repository for one to get a free port  
         Registry registry = LocateRegistry.getRegistry(); 
         
         //the object stub helps to connect the server with the interface
         
         Interface stub = (Interface) UnicastRemoteObject.exportObject(obj, 0);  
       
         
         
         //hey port name 
         
         registry.rebind("Hey", stub); 
         
         System.err.println("Server up and running ");
         
      
       
         
      } catch (Exception e) { 
         System.err.println("Server exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
   } 
}