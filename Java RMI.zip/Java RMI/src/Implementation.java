import java.rmi.RemoteException;
import java.util.*;



//

// Implementing the remote interface 
public class Implementation implements Interface {

	  
	
	
	public double calculation(int x,int y,char op) throws RemoteException {
		double result = 0.000;
		
		switch(op) {
		
		case '+': result= x+y;
				break;
		case '-': result= x-y;
		break;
		case '*': result= x*y;
		break;
		case '/': result= x/y;
		break;
		
		
			
		}
		System.out.println(x+" "+op+" "+y+" result:"+result);
		
		
		return result;
	}
}
	 
	 