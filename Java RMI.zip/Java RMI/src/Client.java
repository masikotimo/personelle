import java.rmi.registry.LocateRegistry; 
import java.rmi.registry.Registry;  
import java.util.*;


public class Client {  
	public int opt;
	public int key;
	public int value;
   private Client() {}  
   public static void main(String[] args) {  
	   
	//  RemoteInterface stub;
      try {  
         // Getting the registry 
    	 // Registry reg=LocateRegistry.getRegistry(9993);
		//	stub = (RemoteInterface)reg.lookup("Hello");
			
         Registry registry = LocateRegistry.getRegistry(null); 
    
         // Looking up the registry for the remote object 
      Interface stub = (Interface) registry.lookup("Hey"); 
    
        
         //scanner helps us to allow input from people thats why we import the java.util class
         Scanner input = new Scanner(System.in);
      
         
         // creating an object of client
         Client cl = new Client();
         
         while(true) {
        	 System.out.println("hello:\n"); 
             System.out.println("1. calculation ");
              
             System.out.println("0.  quit");
             
             cl.opt = input.nextInt();
             if(cl.opt == 1) {
            	 System.out.println("enter integer1:");
            	 int m = input.nextInt();
            	 System.out.println("enter integer2:");
            	 int n = input.nextInt();
            	 System.out.println("enter arithmetic character:");
            	 char ch = input.next().charAt(0);
            	 
                  double x=stub.calculation(m,n,ch);
                  System.out.println("result" +x);
            	
            	 
             }else if(cl.opt == 0) {
            	 System.out.println("Client has closed");
            	 break;
             }
             
            
         }
      } catch (Exception e) {
         System.err.println("Client exception: " + e.toString()); 
         e.printStackTrace(); 
      } 
   } 
}