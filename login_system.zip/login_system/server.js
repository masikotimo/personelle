const express = require ('express');
const parser = require('body-parser');
const morgan = require('morgan');
const mysql = require('mysql');
const session = require('express-session');
const server=express();
const crypto =require('crypto');

//we making our public folder static so it doesnt keep changing
server.use(express.static('./public'))

// creating a session object

server.use(session({
  //its like a secret so that someone doesnot access the information of the session
  secret:'sercret',

  //saves instances of the save user
  resave:true,

  //evenif someone hasnt successfully logged in, still keep track this can even keep track of how many times people have tried to log in failed or succeeded
  saveUninitialized:true
}));


//here we connect to the mysql database 
const connection =mysql.createConnection({
  host:'localhost',
  user:'admin',
  database:'tester',
  password:'mickeygerman1'


})

//uitilising morgan console  which gives information of our server activities

server.use(morgan('short'));

//utilising the body-parser to help us interpret our html that we shall use to access our name attributes from the html pages

server.use(parser.urlencoded({extended:false}))

var html_dir='./public/';

//building routes

//route for the index page
server.get("/", function(request, reponse) {
  reponse.sendfile(html_dir+"index.html");
});

//route for the login page
server.get("/login", function(request, reponse) {
    reponse.sendfile(html_dir+"login.html");
  });

  //route for the signup page
  server.get("/signup", function(request, reponse) {
    reponse.sendfile(html_dir+"signup.html");
  });

  //route for the home page
  server.get("/home", (req, res) => {

    //checking if the user's session is logged in
    if (req.session.loggedin) {
      // res.sendfile(html_dir + "/home.html");
      res.send("welcome back " + req.session.username + "!");
    }
     else
      {
      res.send("please login in to view this page");
    }

    //killing the response listening
    res.end;
  });
  


  //Login  route

  server.post("/auth",(req,res)=>{
  
  const username=req.body.username;
  const password=req.body.password;

  //encrypting our password with md5 encryption method with its digest/keyword(hex) into hash
  const hash =crypto.createHash('md5').update(password).digest('hex')

  

  // response.send(username+' you are welcome. here is your password:'+password);

 

  //if username & password are true or have values
  if (username && password) {

    //connection to the database and should request for all rows win lohin table where the username and password are matching
    connection.query(
      "SELECT * FROM login WHERE Username=? AND Password=?",
      [username, hash],

      //a callback function under connection querry that checks and accesses specific errors. fields are column names,errors,
    function  (error, results, fields) {

      //if results has content
        if (results.length > 0) {

          //confirms someone has logged in and session begins from here
          req.session.loggedin = true;
          //se
          req.session.username = username;
          res.redirect("/home");
        } 
        
        //if one of them is incorrect
        else {

          res.send("incorrect username or Password");
        }

        //we kill the response so that it doesnt continue to listen
        res.end();
      }
    );
   

    //if one of them doesnt have values then report the error
  } else {
    res.send("please enter username and password");
    res.end();
  }
});



//route for signup
  
  server.post("/authet",(req,res)=>{

    //saving the  name attributes into variables
    const surname= req.body.surname;
    const othername= req.body.othername;
    const username= req.body.Uname;
    const email= req.body.Email;
    const password= req.body.password;
    const gender= req.body.gender;

    //encrypting our password with md5 encryption method with its digest/keyword(hex) into hash
    const hash =crypto.createHash('md5').update(password).digest('hex')
    
     //creating a string for our query to insert into table
    const querystring= "INSERT into login  values(?,?,?,?,?,?)";
    

    //using the connection to apply our query string and pass arguments of our variables
    connection.query(querystring,[surname,othername,username,email,hash,gender])


    
    res.redirect("/login")
    res.end();
  });



server.get('/users',(req,res)=>{

let user1 ={name:'timothy',age:24,gender:'male',location:'yess'}
let user2 ={name:'masiko',age:26,gender:'female',location:'lambertisa'}

res.json([user1,user2]);

res.end()

})

server.get('/dbusers',(req,res)=>{

 
  
  connection.query('SELECT *FROM login',(err,rows,fields)=>{

    res.json(rows)
  })
  })
  

 

  //server to begin listening at port 4000

server.listen(4000);

//notifying the console that the connection has started
console.log("running at port 4000");

  
  

