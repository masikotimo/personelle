const chai =require('chai');
const {assert} =chai;
const myfunction =require('./checkone')

describe('myfunction',() => {
    it('factorial of 0 should be 1',()=>{
        assert.equal(myfunction.factorial(0),1)
    });

    it('factorial of 0 should be 1',()=>{
        assert.notEqual(myfunction.factorial(0),2)
    });

});

describe('myfunctionadd',() => {
    it('sum is ',()=>{
        assert.equal(myfunction.add(3,4),7)
    });

    it('sum is not',()=>{
        assert.notEqual(myfunction.add(3,4),2)
    });

});




