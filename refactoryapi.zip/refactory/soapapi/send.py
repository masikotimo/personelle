import requests

headers={}

headers['Authorization'] ='Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNTY5NTgxNTg5LCJqdGkiOiJkNDhlMjU0ZGI4ZjM0MjVmODdiNzhlNTdmMGJkMDc3ZCIsInVzZXJfaWQiOjJ9.AT9FJFTm5dn4DuoHg5zgeQgHWh9mXAwF_tyjQcuPfPw'

r.requests.get('http://localhost:8000/users/',headers=headers)

print(r.text)