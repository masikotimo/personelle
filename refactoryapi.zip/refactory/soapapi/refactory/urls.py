from django.urls import path,include
from rest_framework.urlpatterns import format_suffix_patterns
from refactory import views
from rest_framework import routers

router=routers.DefaultRouter()
# router.register('student ',views.studentlist,basename='studentdetails')

router.register(r'refactory ',views.refactoryview,basename='refactorydetails')

urlpatterns = [
    
    path('',include(router.urls)),
    
]
