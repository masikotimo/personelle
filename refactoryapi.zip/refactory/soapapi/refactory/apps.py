from django.apps import AppConfig


class RefactoryConfig(AppConfig):
    name = 'refactory'
