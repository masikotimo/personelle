from rest_framework import serializers
from .models import pupildetails


class pupilSerializer(serializers.Serializer):


    class Meta:
        model=pupildetails
        # fields=('firstname','lastname')
        fields='__all__'