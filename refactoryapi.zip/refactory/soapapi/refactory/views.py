from django.shortcuts import render

#Create your views here.

from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework import viewsets
from .models import pupildetails
from .serializers import pupilSerializer

class refactoryview(viewsets.ModelViewSet):
    
    queryset=pupildetails.objects.all
    serializer_class=pupilSerializer
    

# class studentlist(APIView):

#     def get(self,request):
#         std=studentdetails.objects.all()
#         serialized=studentSerializer(std,many=True)
#         return Response(serialized.data)

#     def post(self):
#         pass

    

#     def get_extra_actions(cls):
#         return []


