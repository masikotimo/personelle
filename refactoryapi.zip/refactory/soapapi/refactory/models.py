from django.db import models
from datetime import datetime
from django.contrib.auth.models import User
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser
)
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import PermissionsMixin
from django.utils.translation import gettext_lazy as _
from django.utils import timezone





# Create your models here.

class pupil(models.Model):

        pupil_id=models.AutoField(primary_key=True)
        firstname= models.CharField(max_length=255)
        Lastname= models.CharField(max_length=255)
        gender= models.CharField(max_length=255,null=True)
        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
        

        def __str__(self):
            return self.firstname


class pupildetails(models.Model):
        
        pd_id=models.ForeignKey(pupil, null=True, on_delete=models.CASCADE)
        course= models.CharField(max_length=255)
        program= models.CharField(max_length=255)
        

        def __str__(self):
            return self.course    




class  RefactoryUserManager(BaseUserManager):
    
    """
    Custom user model manager where email is the unique identifiers
    for authentication instead of usernames.
    """
    def create_user(self, email, password, **extra_fields):
        """
        Create and save a User with the given email and password.
        """
        if not email:
            raise ValueError(_('The Email must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        """
        Create and save a SuperUser with the given email and password.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))
        return self.create_user(email, password, **extra_fields)

    
    



class RefactoryUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(_('email address'), unique=True)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    Primary_Contact= models.CharField(max_length=255,blank=True,null=True)
    Secondary_Contact= models.CharField(max_length=255,blank=True,null=True)
    # date_joined = models.DateTimeField(default=timezone.now)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = RefactoryUserManager()


    def __str__(self):
        return self.email

    # @property
    # def token(self):
    #     """
    #     Allows us to get a user's token by calling `user.token` instead of
    #     `user.generate_jwt_token().

    #     The `@property` decorator above makes this possible. `token` is called
    #     a "dynamic property".
    #     """
    #     return self._generate_jwt_token()


    # def _generate_jwt_token(self):
    #     """
    #     Generates a JSON Web Token that stores this user's ID and has an expiry
    #     date set to 60 days into the future.
    #     """
    #     dt = datetime.now() + timedelta(days=60)

    #     token = jwt.encode({
    #         'id': self.pk,
    #         'exp': int(dt.strftime('%s'))
    #     }, settings.SECRET_KEY, algorithm='HS256')

    #     return token.decode('utf-8')



class Administrator(RefactoryUser):
        User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
        Admin_id=models.AutoField(primary_key=True)
        
                
        Admin_Photo= models.CharField(max_length=255,blank=True,null=True)

        # created_at = models.DateTimeField(auto_now_add=True)
        # updated_at = models.DateTimeField(auto_now=True)
        

        def __str__(self):
            return self.email

        ordering = ('email')

class Staff(RefactoryUser):
        User=models.OneToOneField(Administrator,on_delete=models.CASCADE)
        Staff_id=models.AutoField(primary_key=True)
        
        Staff_Photo= models.CharField(max_length=255,blank=True,null=True)
        Admin_id=models.ForeignKey(Administrator,related_name='+', blank=True, on_delete=models.CASCADE,null=True)
        

        # created_at = models.DateTimeField(auto_now_add=True)
        # updated_at = models.DateTimeField(auto_now=True)
        

        def __str__(self):
            return self.email


class Applicant(RefactoryUser):
        User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
        applicant_id=models.AutoField(primary_key=True)

        Title=models.CharField(max_length=255,blank=True,null=True)
        applicant_Photo= models.CharField(max_length=255,blank=True,null=True)
        Gender= models.CharField(max_length=255,blank=True,null=True)
        DateofBirth=models.DateField(blank=True,null=True)
        Town_Residential= models.CharField(max_length=255,blank=True,null=True)
        Country= models.CharField(max_length=255,blank=True,null=True)
        Nationality= models.CharField(max_length=255,blank=True,null=True)
        # created_at = models.DateTimeField(auto_now_add=True)
        # updated_at = models.DateTimeField(auto_now=True)
        
        

        def __str__(self):
            return self.email






#applicant,staff,administrator,

# class RefactoryUser(AbstractUser):
#     Surname= models.CharField(max_length=255)
#     GivenName= models.CharField(max_length=255)
#     # Email=models.EmailField(max_length=70,blank=True)

#     def __str__(self):

#         return self.Surname




# class Administrator(RefactoryUser):
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
        
#         Primary_Contact= models.CharField(max_length=255)
#         Secondary_Contact= models.CharField(max_length=255)
        
#         Admin_Photo= models.CharField(max_length=255)
#         Admin_id=models.AutoField(primary_key=True)


#         def 
#         # created_at = models.DateTimeField(auto_now_add=True)
#         # updated_at = models.DateTimeField(auto_now=True)
        

#         def __str__(self):
#             return self.Surname


# class Staff(RefactoryUser):
#         Staff_id=models.AutoField(primary_key=True)
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
#         Primary_Contact= models.CharField(max_length=255)
#         Secondary_Contact= models.CharField(max_length=255)
#         Staff_Photo= models.CharField(max_length=255)
#         Admin_id=models.ForeignKey(Administrator, null=True,related_name='+', on_delete=models.CASCADE)
        

#         # created_at = models.DateTimeField(auto_now_add=True)
#         # updated_at = models.DateTimeField(auto_now=True)
        

#         def __str__(self):
#             return self.Surname


# class Applicant(RefactoryUser):
#         applicant_id=models.AutoField(primary_key=True)
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
#         Title=models.CharField(max_length=255)
#         applicant_Photo= models.CharField(max_length=255)
#         Gender= models.CharField(max_length=255,null=True)
#         DateofBirth=models.DateField(null=True)
#         Town_Residential= models.CharField(max_length=255)
#         Country= models.CharField(max_length=255)
#         Nationality= models.CharField(max_length=255)
        
        
        

#         # created_at = models.DateTimeField(auto_now_add=True)
#         # updated_at = models.DateTimeField(auto_now=True)
        

#         def __str__(self):
#             return self.Surname


# class RefactoryUserManager(BaseUserManager):
#     def create_user(self, email, favorite_color, password=None):
#         """
#         Creates and saves a User with the given email, favorite color
#          and password.
#         """
#         if not email:
#             raise ValueError('Users must have an email address')

#         user = self.model(
#             email=self.normalize_email(email),
#             favorite_color=favorite_color,
#         )

#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, email, favorite_color, password):
#         """
#         Creates and saves a superuser with the given email, date of
#         birth and password.
#         """
#         user = self.create_user(
#             email,
#             password=password,
#             favorite_color=favorite_color,
#         )
#         user.is_admin = True
#         user.save(using=self._db)
#         return user


# class RefactoryUser(AbstractBaseUser):
    
#     email = models.EmailField(
#         verbose_name='email address',
#         max_length=255,
#         unique=True,
#     )
    
#     Surname= models.CharField(max_length=255)
#     GivenName= models.CharField(max_length=255)
#     is_active = models.BooleanField(default=True)
#     is_admin = models.BooleanField(default=False)

#     objects = RefactoryUserManager()

#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = []

#     def __str__(self):
#         return self.email

#     def has_perm(self, perm, obj=None):
#         "Does the user have a specific permission?"
#         # Simplest possible answer: Yes, always
#         return True

#     def has_module_perms(self, app_label):
#         "Does the user have permissions to view the app `app_label`?"
#         # Simplest possible answer: Yes, always
#         return True

#     @property
#     def is_staff(self):
#         "Is the user a member of staff?"
#         # Simplest possible answer: All admins are staff
#         return self.is_admin


# class Administrator(RefactoryUser):
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
        
#         Primary_Contact= models.CharField(max_length=255)
#         Secondary_Contact= models.CharField(max_length=255)
        
#         Admin_Photo= models.CharField(max_length=255)
#         Admin_id=models.AutoField(primary_key=True)

#         # created_at = models.DateTimeField(auto_now_add=True)
#         # updated_at = models.DateTimeField(auto_now=True)
        

#         def __str__(self):
#             return self.Surname



# class Staff(RefactoryUser):
#         Staff_id=models.AutoField(primary_key=True)
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
#         Primary_Contact= models.CharField(max_length=255)
#         Secondary_Contact= models.CharField(max_length=255)
        
#         Staff_Photo= models.CharField(max_length=255)
#         # Admin_id=models.ForeignKey(Administrator,related_name='+', null=True, on_delete=models.CASCADE)
        

#         # created_at = models.DateTimeField(auto_now_add=True)
#         # updated_at = models.DateTimeField(auto_now=True)
        

#         def __str__(self):
#             return self.Surname


# class Applicant(RefactoryUser):
#         applicant_id=models.AutoField(primary_key=True)
#         User=models.OneToOneField(RefactoryUser,on_delete=models.CASCADE)
#         Title=models.CharField(max_length=255)
#         applicant_Photo= models.CharField(max_length=255)
#         Gender= models.CharField(max_length=255,null=True)
#         DateofBirth=models.DateField()
#         Town_Residential= models.CharField(max_length=255)
#         Country= models.CharField(max_length=255)
#         Nationality= models.CharField(max_length=255)
#         created_at = models.DateTimeField(auto_now_add=True)
#         updated_at = models.DateTimeField(auto_now=True)
        
        

#         def __str__(self):
#             return self.Surname





