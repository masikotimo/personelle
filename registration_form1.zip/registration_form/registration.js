//function to validate all field records of the form

const validate = () => {

  //variables
  //variables with xx at the end are the hidden inputs in the html 
  
  
  const name = document.getElementById("name");
  const zip = document.getElementById("zip");
  const mailformat=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  const country=document.getElementById('country');
  const language=document.getElementsByName('language');
  var radiobtn=document.getElementsByName('radio'); 
  const radioxx=document.getElementById('radioxx');
  const languagexx=document.getElementById('languagexx');


  

  //validating sex


  var check=0;
  
  //looping through the radio buttons to check if none has been selected 
  for(let i=0;i<radiobtn.length;i++){
    if(radiobtn.item(i).checked==false){
     check++
    }
   
  }

  //if the number of none selected is equal to the length of radio buttons then none as been selected
  if(check ==radiobtn.length){
      radioxx.type='text'
      radioxx.value = "choose sex";
      radioxx.style.color='red'

  }

  //validating language
  var lang=0;
  
  //looping through the checkboxes to check if none has been selected 
  for(let i=0;i<language.length;i++){
    if(language.item(i).checked==false){
     lang++;
    }
   
  }

  //if the number of none selected is equal to the length of checkboxes then none has also been selected
  if(lang ==language.length){
      languagexx.type='text'
      languagexx.value = "choose language";
      languagexx.style.color='red'

  }
  
 //validating id
  

 //checking if field has nothing entered if yes it sends error complaint
  if (id.value == "" ||id.value==null) {
    id.style.border = "1px solid green";
    id.value = "Field required";
    id.style.color='red'
  
  }

  //if field was entered then..
  else{

    //checking if the id field is  within the 5-12 size if no sends error message
    if (id.value.length>=5 && id.value.length<=12) {
      
      
    
    }

    else{

      id.style.border = "1px solid red";
      idx.type='text'
      idx.value = "Must be length of 5-12";
      idx.style.color='red'
    }

  }
  


//validating password


//checking if field has nothing entered if yes it sends error complaint 
  if (password.value == "" ||password.value==null) {
    password.style.border = "1px solid green";
    password.placeholder = "Required";
    password.style.color='red'
  
  }

  else{

    //checking if the password field is  within the 7-12 length if no sends error message
    if (password.value.length>=7 && password.value.length<=12) {
      
      
    
    }
    else{
      password.style.border = "1px solid red";
      passwordxx.value = "Must be length of 7-12";
      passwordxx.style.color='red'
      passwordxx.type='text'

    }


  }
 

  //validating name

  //checking if name field has nothing entered if yes it sends error complaint 
  if (name.value == "" || name.value==null) {
    name.style.border = "1px solid red";
    name.value = "Required";
    name.style.color='red'
  
  }

  else{

     //checking if value entered is  a number and if true then send error message
    if (isNaN(name.value)==false ) {
      name.style.border = "1px solid red";
      namexx.value = "should be a string";
      namexx.style.color='red';
      namexx.type='text'
    
    }

  }

 

  //validating zip

  //checking if zip field has nothing entered if yes it sends error complaint 

  if (zip.value == "" || zip.value==null) {
    zip.style.border = "1px solid red";
    zip.value = "Required";
    zip.style.color='red'
  
  }
  else{
    //checking if value is not a number and if true then send error message
    if(isNaN(zip.value) ){
      zipxx.style.color='red'
      zip.style.border = "1px solid green";
      zipxx.value = "should be a number";
      zipxx.type='text'
      
  
    }


  }
  
  




  //validating country

  //checking if country field has nothing selected if yes it sends error complaint 
  if(country.value==null ||country.value==""){
    country.style.border = "1px solid red";
    countryxx.value = "Required";
    countryxx.style.color='red'
    countryxx.type='text'

  }


  
 //validating email

 //checking if email field has nothing entered if yes it sends error complaint 

 if(email.value==null ||email.value==""){
  email.style.border = "1px solid red";
  email.value = "Required";
  email.style.color='red'

}

else{

  //checking if the email is in the right format
  if(email.value.match(mailformat)){

    
    return true;

   
  }

  //if its not in its right format then send error messages
  
  else{
    email.style.border = "1px solid red";
    emailxx.style.color='red'
   emailxx.value = "invalid email";
   emailxx.type='text'
    return false;
  }

}

  



};
